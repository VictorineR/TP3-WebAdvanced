<template>
  <div id="days-container">
    <div v-for="(month, index) in months" class="day" :key="month">
      <strong>{{ month }}</strong>
      <days-of-month
        :year="year"
        :month="index + 1"
        :ferie="ferie"
      ></days-of-month>
    </div>
  </div>
</template>

<script>
const DaysOfMonth = window.httpVueLoader('./components/DaysOfMonth.vue')
module.exports = {
  components: { DaysOfMonth },
  props: ['year'],
  data () {
    return {
      ferie: [],
      months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
    }
  },
  created () {
    fetch('http://vps-4401e6e0.vps.ovh.net/api/v2/PublicHolidays/' + this.year + '/FR')
    .then((res) => res.json())
    .then((data) => { this.ferie = data })
  }
}
</script>

<style scoped>
  #days-container {
    display: flex
  }

  .day {
    flex: 1
  }

  .day ul {
    padding-left: 0;
  }

  .day li {
    list-style: none;
  }
</style>