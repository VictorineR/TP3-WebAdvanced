<template>
  <ul>
    <li
      v-for="day of nbrOfDays(year, month)"
      :key="day"
      :style="{ fontWeight: isFerie(day) }"
    >
      {{ day }}: {{ dayOfWeek(year, month, day) }} {{ getLocalName(day) }}
    </li>
  </ul>
</template>

<script>
module.exports = {
  props: ["year", "month", "ferie"],
  data() {
    return {
      week: [
        "Dimanche",
        "Lundi",
        "Mardi",
        "Mercredi",
        "Jeudi",
        "Vendredi",
        "Samedi",
      ],
    };
  },
  methods: {
    nbrOfDays(year, month) {
      return new Date(year, month, 0).getDate();
    },
    dayOfWeek(year, month, day) {
      const now = new Date(year, month - 1, day);
      return this.week[now.getDay()];
    },
    isFerie(day) {
      for (const item of this.ferie) {
        const date = new Date(item.date);
        if (date.getMonth() + 1 === this.month && date.getDate() === day) {
          return "bold";
        }
      }
      return "";
    },
    getLocalName(day) {
      for (const item of this.ferie) {
        const date = new Date(item.date);
        if (date.getMonth() + 1 === this.month && date.getDate() === day) {
          return ": " + item.localName;
        }
      }
      return "";
    },
  },
};
</script>