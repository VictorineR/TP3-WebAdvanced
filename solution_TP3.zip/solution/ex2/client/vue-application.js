const DaysOfMonth = window.httpVueLoader('./components/DaysOfMonth.vue')

Vue.component('hello-world', {
  data: function () {
    return {
      message: ', World'
    }
  },
  template: `<p>Hello{{ message }}!</p>`
})

var app = new Vue({
  el: '#app',
  data: {
    today: new Date(),
    year: 2020,
    month: 1,
    months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
  },
  methods: {
    nbrOfDays (day) {
      return (new Date(day.getFullYear(), day.getMonth() + 1, 0)).getDate()
    }
  },
  components: { DaysOfMonth }
})
