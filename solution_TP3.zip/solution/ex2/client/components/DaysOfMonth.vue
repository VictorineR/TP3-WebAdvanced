<template>
  <ul>
    <li v-for="day of daysOfMonth(year, month)" :key="day">
      {{ day }}: {{ dayOfWeek(year, month, day) }}
    </li>
  </ul>
</template>

<script>
module.exports = {
  props: ['year', 'month'],
  data () {
    return {
      week: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
    }
  },
  methods: {
    nbrOfDays (day) {
      return (new Date(day.getFullYear(), day.getMonth() + 1, 0)).getDate()
    },
    daysOfMonth(year, month) {
      const days = [];
      const nbr = this.nbrOfDays(new Date(year, month, 0));
      for (let i = 1; i <= nbr; i++) {
        days.push(i);
      }
      return days;
    },
    dayOfWeek(year, month, day) {
      const now = new Date(year, month, day);
      return this.week[now.getDay()];
    },
  },
};
</script>