<template>
  <div>Hi everyone {{ message }}</div>
</template>

<script>
module.exports = {
  data: function () {
    return {
      message: 'it works'
    }
  }
}
</script>
