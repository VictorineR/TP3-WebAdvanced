const ShowDaysOfYear = window.httpVueLoader('./components/ShowDaysOfYear.vue')
const HelloOtherWorld = window.httpVueLoader('./components/HelloOtherWorld.vue')

Vue.component('hello-world', {
  data: function () {
    return {
      message: ', World'
    }
  },
  template: `<p>Hello{{ message }}!</p>`
})

const routes = [
  { path: '/hello-world', component: HelloOtherWorld },
  { path: '/days/:year', component: ShowDaysOfYear }
]

const router = new VueRouter({
  routes
})

var app = new Vue({
  router,
  el: '#app',
  data: {
    today: new Date(),
    year: 2020,
    months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
  },
  methods: {
    nbrOfDays (day) {
      return (new Date(day.getFullYear(), day.getMonth() + 1, 0)).getDate()
    }
  }
})
