<template>
  <days-of-year :year="$route.params.year"></days-of-year>
</template>

<script>
const DaysOfYear = window.httpVueLoader('./components/DaysOfYear.vue')

module.exports = {
  components: { DaysOfYear },
  data () {
    return {
    }
  }
}
</script>