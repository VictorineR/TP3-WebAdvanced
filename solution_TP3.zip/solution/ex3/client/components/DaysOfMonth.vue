<template>
  <ul>
    <li v-for="day of nbrOfDays(year, month)" :key="day">
      {{ day }}: {{ dayOfWeek(year, month, day) }}
    </li>
  </ul>
</template>

<script>
module.exports = {
  props: ['year', 'month'],
  data () {
    return {
      week: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
    }
  },
  methods: {
    nbrOfDays (year, month) {
      return (new Date(year, month, 0)).getDate()
    },
    dayOfWeek(year, month, day) {
      const now = new Date(year, month - 1, day);
      return this.week[now.getDay()];
    },
  },
};
</script>