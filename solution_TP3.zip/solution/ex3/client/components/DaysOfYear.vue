<template>
  <div id="days-container">
    <div v-for="(month, index) in months" class="day" :key="month">
      <strong>{{ month }}</strong>
      <days-of-month
        :year="year"
        :month="index + 1"
      ></days-of-month>
    </div>
  </div>
</template>

<script>
const DaysOfMonth = window.httpVueLoader('./components/DaysOfMonth.vue')
module.exports = {
  components: { DaysOfMonth },
  props: ['year'],
  data () {
    return {
      months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
    }
  }
}
</script>

<style scoped>
  #days-container {
    display: flex
  }

  .day {
    flex: 1
  }

  .day ul {
    padding-left: 0;
  }

  .day li {
    list-style: none;
  }
</style>